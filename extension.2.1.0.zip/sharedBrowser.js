var browser = {
  Chrome: 'Chrome',
  Firefox: 'Firefox',
  Edge: 'Edge'
};
var browserHostType = browser.Chrome;
